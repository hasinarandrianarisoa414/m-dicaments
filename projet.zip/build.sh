set -e
npm install --no-audit --no-fund
npx cap add android
mkdir -p android/app/src/main/res/raw
cp resources/raw/*.wav android/app/src/main/res/raw/
M=android/app/src/main/AndroidManifest.xml
for p in POST_NOTIFICATIONS SCHEDULE_EXACT_ALARM VIBRATE RECEIVE_BOOT_COMPLETED WAKE_LOCK; do
  grep -q "android.permission.$p" $M || sed -i "s#</manifest>#    <uses-permission android:name=\"android.permission.$p\" />\n</manifest>#" $M
done
npx cap sync android
cd android && ./gradlew assembleDebug --no-daemon
